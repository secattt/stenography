#!/bin/bash

# Check if exactly 2 arguments (files) are provided
if [ $# -ne 2 ]; then
    echo "Please provide exactly two file paths."
    exit 1
fi

# Original file and the file after data hiding
file1="$1"  # Original file
file2="$2"  # File after data hiding

# Check if the files exist
if [ ! -f "$file1" ]; then
    echo "Original file does not exist: $file1"
    exit 1
fi

if [ ! -f "$file2" ]; then
    echo "File after data hiding does not exist: $file2"
    exit 1
fi

# Get the size of file1 and file2 (in bytes)
size1=$(stat --format="%s" "$file1")
size2=$(stat --format="%s" "$file2")

# Calculate the size difference between the two files
size_diff=$((size2 - size1))

# Set maximum allowed size difference (100 KB)
threshold=102400  # 100 KB = 102400 bytes

if [ "$size_diff" -le "$threshold" ]; then
    echo "The size of the stego file is acceptable (does not exceed 100KB)."
else
    echo "Warning: The stego file size exceeds the original by more than 100KB."
fi


#!/usr/bin/env python3
import os
import cv2
import sys
import moviepy.editor
from os import path

def video_to_frames(input_video):
    # Kiểm tra file video tồn tại
    if not os.path.isfile(input_video):
        print("Error: Video file not found!")
        return False

    # Tạo thư mục frames nếu chưa tồn tại
    if not os.path.exists("frames"):
        os.makedirs("frames")

    # Tạo thư mục video nếu chưa tồn tại
    if not os.path.exists("video"):
        os.makedirs("video")

    # Đọc video
    cap = cv2.VideoCapture(input_video)
    if not cap.isOpened():
        print(f"Error: Could not open video file {input_video}. Trying FFmpeg fallback...")
        # Fallback sang FFmpeg
        os.system(f"ffmpeg -i {input_video} frames/frame%d.png 2>/dev/null")
        if not any(f.startswith("frame") and f.endswith(".png") for f in os.listdir("frames/")):
            print(f"Error: Failed to extract frames from {input_video} using FFmpeg.")
            return False
        print("Frames saved using FFmpeg!")
    else:
        fps = cap.get(cv2.CAP_PROP_FPS)
        print(f"fps = {fps}")

        current_frame = 0
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            name = f"frame{current_frame}.png"
            print(f"Creating: {name}")
            cv2.imwrite(path.join("frames", name), frame)
            current_frame += 1

        cap.release()
        cv2.destroyAllWindows()
        print("Frames saved!")

    # Trích xuất âm thanh từ video
    try:
        video = moviepy.editor.VideoFileClip(input_video)
        audio = video.audio
        if audio is not None:
            audio.write_audiofile("video/output.mp3")
            print("Audio extracted successfully!")
        else:
            print("No audio found in the video.")
        audio.close()
        video.close()
    except Exception as e:
        print(f"Error extracting audio: {e}")

    return True

def main_extract():
    if len(sys.argv) != 2:
        print("Usage: python3 extract_frames.py <input_video_path>")
        sys.exit(1)

    input_video = sys.argv[1]  # Get video path from command line argument
    success = video_to_frames(input_video)
    if success:
        print("Frame extraction completed successfully!")
    else:
        print("Frame extraction failed!")

if __name__ == "__main__":
    main_extract()

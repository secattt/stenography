import cv2
import numpy as np
import os

# ======================== CONFIGURATION ========================
OUTPUT_VIDEO = "output.avi"
FRAME_FOLDER = "extract_frames"
TARGET_FRAME_INDEX = 100
BLOCK_SIZE = 8
BIT_PLANES = [2, 3]
COLOR_CHANNEL = 0
POSITION_FILE = "positions.txt"
SECRET_LENGTH = 100  

# ======================== MAIN FUNCTION ========================

def extract_secret_from_video():
    # Identify the target frame
    print("[1/2] Reading frame to extract the secret...")
    frame_paths = sorted([f for f in os.listdir(FRAME_FOLDER) if f.endswith('.png')])
    target_frame_path = os.path.join(FRAME_FOLDER, frame_paths[TARGET_FRAME_INDEX])

    # Extract the secret from the frame
    print("[2/2] Extracting the secret from the frame...")
    extracted_data = extract_data_from_frame(target_frame_path, BLOCK_SIZE, BIT_PLANES, COLOR_CHANNEL)
    if isinstance(extracted_data, str):
        print(f"Extracted secret: {extracted_data}")
    else:
        print("Unable to decode the message. Raw data:")
        print(format_raw_data(extracted_data))

# ======================== FUNCTIONS ========================
def extract_data_from_frame(frame_path, block_size, bit_planes, color_channel):
    """Extract data from a frame"""
    frame = cv2.imread(frame_path)
    if frame is None:
        print(f"Unable to read the frame: {frame_path}")
        return None

    # Check for the positions.txt file
    if not os.path.exists(POSITION_FILE):
        print(f"Positions file not found: {POSITION_FILE}")
        return None

    # Read the list of coordinates and bit planes from positions.txt
    extracted_bits = []
    with open(POSITION_FILE, 'r') as f:
        positions = [tuple(map(int, line.split())) for line in f]

    # Read bits from the recorded positions
    for pos in positions:
        x, y, bit = pos
        if bit not in BIT_PLANES:
            print(f"Invalid bit plane: {bit} (position: {x}, {y})")
            continue
        channel_data = frame[:, :, color_channel].astype(np.int16)
        bit_plane = (channel_data >> bit) & 1
        extracted_bits.append(str(bit_plane[x, y]))

    # Convert the bit string to bytes
    binary_data = ''.join(extracted_bits)
    bytes_data = [int(binary_data[i:i+8], 2) for i in range(0, len(binary_data), 8)]
    
    # Look for the end of the message (e.g., null byte or special character)
    try:
        # Only take the part of the data before encountering an invalid byte
        end_index = bytes_data.index(0) if 0 in bytes_data else SECRET_LENGTH
        secret_message = bytes(bytes_data[:end_index]).decode('utf-8')
        return secret_message
    except (UnicodeDecodeError, ValueError):
        # If there's an error, only take the readable ASCII part
        readable_part = []
        for byte in bytes_data[:SECRET_LENGTH]:
            if 32 <= byte <= 126:  # Only take printable ASCII characters
                readable_part.append(byte)
            else:
                break  # Stop when encountering a non-ASCII character
        return bytes(readable_part).decode('ascii', errors='ignore')

def format_raw_data(raw_data):
    """Format raw data into a hex string for inspection"""
    return ' '.join(f'{byte:02X}' for byte in raw_data)

# ======================== RUN PROGRAM ========================
if __name__ == "__main__":
    extract_secret_from_video()

